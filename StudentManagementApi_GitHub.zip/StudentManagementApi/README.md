# Student Management REST API

A beginner ASP.NET Core Web API project demonstrating CRUD operations using an in-memory list (no database).

## Requirements
- Visual Studio with the ASP.NET and web development workload
- .NET 10 SDK

## Run in Visual Studio
1. Open `StudentManagementApi.csproj` in Visual Studio.
2. Select the `http` launch profile.
3. Press `F5` or click **Start**.
4. Browse to `http://localhost:5080/api/students`.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | Get all students |
| GET | `/api/students/1` | Get a student by ID |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/1` | Update a student |
| DELETE | `/api/students/2` | Delete a student |

Use `StudentManagementApi.http` in Visual Studio to send sample requests.

## Note
This project stores data in memory. Changes are temporary and reset when the application restarts. It does not use a database.
